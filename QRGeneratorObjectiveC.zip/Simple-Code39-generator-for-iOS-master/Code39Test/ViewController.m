//
//  ViewController.m
//  Code39Test
//
//  Created by Lin Patrick on 10/17/15.
//  Copyright © 2015 Gemmy Planet, Inc. All rights reserved.
//

#import "ViewController.h"
#import "Code39.h"

@interface ViewController ()

@property (strong, nonatomic) IBOutlet UITextField *barTF;
@property (strong, nonatomic) IBOutlet UITextField *textTF;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}

// bar code generator

-(void)barGenerator
{
    // Do any additional setup after loading the view, typically from a nib.
    int barcode_width = 300;
    int barcode_height =200;
    UIImage *code39Image = [Code39 code39ImageFromString:self.textTF.text Width:barcode_width Height:barcode_height];
    
    UIImageView *iv = [[UIImageView alloc] initWithImage:code39Image];
    iv.frame = CGRectMake(40,20,barcode_width, barcode_height);
    [self.view addSubview:iv];
}

- (IBAction)doneBtn_Action:(id)sender
{
      [self barGenerator];
}


-(BOOL)textFieldShouldReturn:(UITextField*)textField;
{
    [textField resignFirstResponder];
    
    return YES;

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
